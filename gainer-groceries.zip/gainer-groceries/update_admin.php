<?php
require 'config.php';
$newEmail = 'admin@gainergroceries.co.zw';
$newPass = 'Nakiso12';
$hashedPass = password_hash($newPass, PASSWORD_BCRYPT, ['cost' => 12]);

// Check if any admin exists
$stmt = $pdo->query("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
$admin = $stmt->fetch();

if ($admin) {
    echo "Updating existing admin...\n";
    $stmt = $pdo->prepare("UPDATE users SET email = ?, password = ? WHERE id = ?");
    $stmt->execute([$newEmail, $hashedPass, $admin['id']]);
} else {
    echo "Creating new admin...\n";
    $stmt = $pdo->prepare("INSERT INTO users (email, password, full_name, role, status) VALUES (?, ?, 'Admin User', 'admin', 'active')");
    $stmt->execute([$newEmail, $hashedPass]);
}
echo "Done!\n";
?>
