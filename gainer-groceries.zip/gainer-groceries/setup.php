<?php
// CLI-Only Admin Setup Script
// This script can ONLY be run from the command line for security
// Usage: php setup.php <email> <password> <full_name>

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    die('ERROR: This script can only be run from command line. HTTP access is forbidden for security.');
}

require_once 'config.php';

// Get command line arguments
$email = $argv[1] ?? null;
$password = $argv[2] ?? null;
$full_name = $argv[3] ?? null;

// Display usage if arguments missing
if (!$email || !$password || !$full_name) {
    echo "╔════════════════════════════════════════════════════════╗\n";
    echo "║     Gainer Groceries - Admin Account Setup             ║\n";
    echo "╚════════════════════════════════════════════════════════╝\n\n";
    echo "Usage: php setup.php <email> <password> <full_name>\n\n";
    echo "Example:\n";
    echo "  php setup.php admin@gainergroceries.co.zw SecurePassword123 \"Admin User\"\n\n";
    echo "Requirements:\n";
    echo "  - Email: Valid email format\n";
    echo "  - Password: Minimum 8 characters\n";
    echo "  - Full Name: Any string with spaces allowed\n\n";
    exit(1);
}

try {
    // Check if setup lock file exists (setup already completed)
    $setupLockFile = __DIR__ . '/.setup-complete';
    if (file_exists($setupLockFile)) {
        echo "⚠️  WARNING: Setup has already been completed on " . file_get_contents($setupLockFile) . "\n";
        echo "If you need to reset, delete the .setup-complete file and clear admin users from the database.\n";
        exit(1);
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "❌ ERROR: Invalid email format: $email\n";
        exit(1);
    }

    // Validate password strength
    if (strlen($password) < 8) {
        echo "❌ ERROR: Password must be at least 8 characters (provided: " . strlen($password) . " chars)\n";
        exit(1);
    }

    // Validate full name
    $full_name = trim($full_name);
    if (empty($full_name)) {
        echo "❌ ERROR: Full name cannot be empty\n";
        exit(1);
    }

    // Check if admin account already exists
    $checkSetup = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
    $result = $checkSetup->fetch();
    
    if ($result['count'] > 0) {
        echo "❌ ERROR: Admin account already exists in database\n";
        echo "To reset: Delete admin users and remove .setup-complete file\n";
        exit(1);
    }

    // Hash password using BCRYPT (cost 12 for strong security)
    echo "🔐 Hashing password...\n";
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

    // Insert admin user into database
    echo "💾 Creating admin account...\n";
    $stmt = $pdo->prepare("INSERT INTO users (email, password, full_name, role, status) VALUES (?, ?, ?, 'admin', 'active')");
    $stmt->execute([$email, $hashedPassword, $full_name]);

    // Create setup lock file
    file_put_contents($setupLockFile, date('Y-m-d H:i:s'));

    // Success message
    echo "\n";
    echo "╔════════════════════════════════════════════════════════╗\n";
    echo "║           ✓ SETUP COMPLETED SUCCESSFULLY               ║\n";
    echo "╚════════════════════════════════════════════════════════╝\n\n";
    echo "Admin Account Details:\n";
    echo "  Email:      $email\n";
    echo "  Full Name:  $full_name\n";
    echo "  Role:       admin\n";
    echo "  Status:     active\n\n";
    echo "⚠️  IMPORTANT: This setup script should be deleted from production before deploying!\n";
    echo "   Delete this file (setup.php) immediately after setup.\n\n";
    echo "✓ Setup is now locked. To re-run, delete .setup-complete file first.\n";

} catch (PDOException $e) {
    echo "❌ DATABASE ERROR: " . $e->getMessage() . "\n";
    exit(1);
} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    exit(1);
}
?>
