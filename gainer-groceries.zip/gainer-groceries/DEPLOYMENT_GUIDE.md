# Gainer Groceries - cPanel Shared Hosting Deployment Guide

Complete step-by-step instructions for deploying the Gainer Groceries application to cPanel shared hosting.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Step 1: Prepare Your Domain & cPanel](#step-1-prepare-your-domain--cpanel)
3. [Step 2: Create Database & User](#step-2-create-database--user)
4. [Step 3: Upload Files via FTP](#step-3-upload-files-via-ftp)
5. [Step 4: Configure Application](#step-4-configure-application)
6. [Step 5: Initialize Database](#step-5-initialize-database)
7. [Step 6: Create Admin Account](#step-6-create-admin-account)
8. [Step 7: Verify Setup](#step-7-verify-setup)
9. [Step 8: Clean Up & Secure](#step-8-clean-up--secure)
10. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before you start, you need:

✓ A domain name pointing to your cPanel hosting account  
✓ cPanel login credentials (username & password)  
✓ FTP client software (FileZilla, WinSCP, or similar)  
✓ Text editor (Notepad++, VS Code, or similar)  
✓ Access to command line/terminal on your local machine  
✓ PHP 7.4+ support (check with your hosting provider)

---

## Step 1: Prepare Your Domain & cPanel

### 1.1 Access Your cPanel Dashboard

1. Visit your hosting provider's control panel URL (usually `cpanel.yourdomain.com` or `yourdomain.com:2083`)
2. Login with your cPanel username and password
3. You should see the cPanel dashboard

### 1.2 Check PHP Version

1. In cPanel, search for **"Select PHP Version"** or **"Software Collections"**
2. Make sure PHP version is **7.4 or higher**
3. If not, upgrade through your hosting provider

### 1.3 Note Your Details

Write down the following (you'll need these later):

```
Domain:              yourdomain.com
cPanel Username:     your_cpanel_username
FTP Host:            yourdomain.com or ftp.yourdomain.com
FTP Username:        Will be created in Step 1.4
FTP Password:        Will be created in Step 1.4
```

### 1.4 Create FTP Account (Optional but Recommended)

1. In cPanel, find **"FTP Accounts"**
2. Click **"Create FTP Account"**
3. For username, use: `gainer_deploy` (or your preference)
4. Set a strong password and note it down
5. Set quota to unlimited
6. Click **"Create FTP Account"**

---

## Step 2: Create Database & User

### 2.1 Create MySQL Database

1. In cPanel, find **"MySQL Databases"** or **"Databases"**
2. In the "Create New Database" section:
   - Database Name: Enter `yourusername_gainer` (replace `yourusername` with your cPanel username)
   - Click **"Create Database"**
3. Note down the full database name (should be something like: `yourusername_gainer`)

### 2.2 Create Database User

1. In the same MySQL Databases section, scroll to "MySQL Users"
2. Username: Enter `yourusername_gguser` (or similar)
3. Password: Create a **strong password** (use a password manager)
4. Click **"Create User"**
5. **Save this information:**
   ```
   Database Username:  yourusername_gguser
   Database Password:  YourStrongPassword123!
   ```

### 2.3 Assign User to Database

1. Scroll to "Add User To Database"
2. Select your new user (`yourusername_gguser`) from dropdown
3. Select your new database (`yourusername_gainer`) from dropdown
4. Click **"Add"**
5. When prompted, select **ALL PRIVILEGES** and click **"Make Changes"**

---

## Step 3: Upload Files via FTP

### 3.1 Connect via FTP Client

**Using FileZilla:**

1. Download [FileZilla](https://filezilla-project.org/) if you don't have it
2. Open FileZilla
3. Go to **File → Site Manager**
4. Click **"New Site"**
5. Fill in the details:
   ```
   Protocol:      SFTP - SSH File Transfer Protocol
   Host:          yourdomain.com
   Logon Type:    Normal
   User:          your_ftp_username (from Step 1.4)
   Password:      your_ftp_password (from Step 1.4)
   Port:          22 (for SFTP) or leave default
   ```
6. Click **"Connect"**

### 3.2 Navigate to Public HTML

In FileZilla's right panel (server), navigate to:
```
public_html/
```

If your domain uses a subdomain (e.g., `shop.yourdomain.com`), navigate to the corresponding folder.

### 3.3 Upload Project Files

1. On the left panel (your computer), locate your project folder: `gainer-groceries-2`
2. Select all files and folders **except**:
   - `.git` (if present)
   - `.gitignore`
   - `node_modules` (if present)
   - `README.md`
   - `setup.php` (we'll handle this separately)

3. Drag and drop them to `public_html/` on the right panel
4. Wait for upload to complete (you'll see status messages)

### 3.4 Upload setup.php Separately

After the main files are uploaded:

1. **Right-click on `setup.php`** in FileZilla's left panel
2. Select **"File permissions"**
3. Set to `755` (read, write, execute for owner)
4. Click **"OK"** then upload

---

## Step 4: Configure Application

### 4.1 Update config.php with Database Credentials

1. In FileZilla, right-click `config.php` in `public_html/`
2. Select **"View/Edit"** (this opens it in your default text editor)
3. Update the database credentials:

```php
<?php
// Database configuration
$host = 'localhost';
$dbname = 'yourusername_gainer';      // Your database name from Step 2.1
$username = 'yourusername_gguser';    // Your database user from Step 2.2
$password = 'YourStrongPassword123!'; // Your database password from Step 2.2

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}
?>
```

4. **Save the file** (Ctrl+S or Cmd+S)
5. FileZilla will ask if you want to upload changes — click **"Yes"**

### 4.2 Verify File Permissions

Important: Set correct permissions for security:

1. **Right-click `config.php`** → **"File permissions"** → Set to `644`
2. **Right-click `api/` folder** → **"File permissions"** → Set to `755` (recursively)
3. **Right-click `your-images/` folder** → **"File permissions"** → Set to `755` (recursively)

---

## Step 5: Initialize Database

### 5.1 Import SQL Schema

1. In cPanel, find **"phpMyAdmin"**
2. Click it to open
3. On the left, select your database: `yourusername_gainer`
4. Click the **"Import"** tab
5. Click **"Choose File"** and select `database.sql` from your project
6. Click **"Import"**
7. You should see success message with tables created

**If Import Fails:**
- Check database name matches exactly
- Ensure user has ALL PRIVILEGES on the database
- Try importing the SQL manually via phpMyAdmin SQL tab

---

## Step 6: Create Admin Account

### Option A: Via Command Line (Recommended)

**If your hosting provider gives you SSH/Terminal access:**

1. In cPanel, find **"Terminal"** or **"SSH Keys"**
2. Open Terminal
3. Navigate to your project:
   ```bash
   cd public_html
   ```
4. Run the setup script:
   ```bash
   php setup.php admin@gainergroceries.co.zw "SecurePassword123!" "Admin User"
   ```
5. You should see success message with admin details

### Option B: Via cPanel Terminal

1. In cPanel, find **"Terminal"**
2. Execute the same command as Option A
3. Wait for success message

### Option C: Manual Database Insert (If SSH Not Available)

1. Open cPanel → **phpMyAdmin**
2. Select your database: `yourusername_gainer`
3. Click the **"SQL"** tab
4. Paste this query (update the email/password):
   ```sql
   INSERT INTO users (email, password, full_name, role, status) 
   VALUES ('admin@gainergroceries.co.zw', '$2y$12$HASH_HERE', 'Admin User', 'admin', 'active');
   ```

**⚠️ Important:** You MUST hash the password first!

5. To generate the password hash, create a small PHP file:
   - In your text editor, create `hash.php`:
     ```php
     <?php
     echo password_hash("YourPassword123", PASSWORD_BCRYPT, ['cost' => 12]);
     ?>
     ```
   - Upload to `public_html/hash.php`
   - Visit `https://yourdomain.com/hash.php` in your browser
   - Copy the hash output
   - Replace `$2y$12$HASH_HERE` in the SQL query above with your hash
   - Run the SQL query in phpMyAdmin

**Save your admin credentials:**
```
Email:    admin@gainergroceries.co.zw
Password: YourPassword123
```

---

## Step 7: Verify Setup

### 7.1 Test Website Access

1. Open your browser
2. Visit: `https://yourdomain.com`
3. You should see the Gainer Groceries homepage
4. Verify homepage loads correctly

### 7.2 Test Admin Login

1. Visit: `https://yourdomain.com/admin-login.html`
2. Enter the admin credentials from Step 6:
   - Email: `admin@gainergroceries.co.zw`
   - Password: Your password
3. Click **"Login"**
4. You should be directed to `admin-dashboard.html`

### 7.3 Test API Endpoints

Test that the backend is working:

1. In your browser, open Developer Tools (F12)
2. Go to **Console** tab
3. Paste and run:
   ```javascript
   fetch('https://yourdomain.com/api/products.php')
     .then(r => r.json())
     .then(d => console.log(d))
   ```
4. You should see product data in the console

### 7.4 Check Database

1. Open cPanel → phpMyAdmin
2. Select your database
3. Verify you see tables: `products`, `users`, `orders`, `settings`, `slides`
4. Click on `users` table and verify your admin account is there

---

## Step 8: Clean Up & Secure

### 8.1 Delete setup.php

⚠️ **CRITICAL SECURITY STEP:**

1. In FileZilla, right-click `setup.php` in `public_html/`
2. Select **"Delete"**
3. Confirm deletion

**Why?** The setup script should NEVER be accessible on a production server. Anyone could use it to create unauthorized admin accounts.

### 8.2 Delete hash.php (if created)

If you created `hash.php` in Step 6.3:

1. In FileZilla, right-click `hash.php` in `public_html/`
2. Select **"Delete"**

### 8.3 Delete .setup-complete File (Optional)

If you used CLI setup (Step 6 Option A), a `.setup-complete` file was created:

1. In FileZilla, enable **"Show hidden files"**:
   - Go to **View → Show hidden files**
2. Right-click `.setup-complete` and delete it

### 8.4 Set File Permissions for Security

Key files should have restricted permissions:

```
config.php          : 644 (read-only for web server)
api/*.php           : 644
admin-*.html        : 644
your-images/        : 755 (must be writable for uploads)
```

Ensure these are NOT accessible:
- `.setup-complete` — DELETE it
- `setup.php` — DELETE it
- `database.sql` — Consider deleting it
- `.git/` — Delete if present

### 8.5 Enable HTTPS

1. In cPanel, find **"Auto SSL"** or **"SSL/TLS Manager"**
2. Install a free SSL certificate (Let's Encrypt)
3. Update your `.htaccess` to force HTTPS:

Create `.htaccess` file in `public_html/`:
```apache
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Prevent directory listing
Options -Indexes
```

---

## Step 9: Configure API CORS (If Needed)

If your frontend and API are on different subdomains, update `api/` files:

In each API file (e.g., `api/products.php`), add:

```php
header('Access-Control-Allow-Origin: https://yourdomain.com');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
```

---

## Step 10: Performance & Optimization

### 10.1 Enable Caching

In cPanel, find **"Optimize Website"** or **"Cache Manager"** and enable:
- Browser caching
- Gzip compression

### 10.2 Database Optimization

1. In phpMyAdmin, select all tables
2. Click the **"With selected"** dropdown
3. Select **"Optimize table"**

### 10.3 Monitor Error Logs

Regularly check for errors:

1. In cPanel, find **"Error Log"**
2. Check for any PHP warnings or errors
3. Fix issues promptly

---

## Troubleshooting

### Database Connection Failed

**Error:** `Database connection failed: SQLSTATE[HY000] [2002]`

**Solution:**
1. Verify database name in `config.php` matches cPanel database
2. Verify username/password are correct
3. Ensure user has privileges on database
4. Use `localhost` as host (not IP address)

### 403 Forbidden Error

**Error:** `You don't have permission to access this resource`

**Solution:**
1. Check file permissions — should be `644` for files, `755` for directories
2. Ensure `public_html/` is the correct folder
3. Check if `.htaccess` has syntax errors

### 404 Not Found

**Error:** `The requested resource was not found`

**Solution:**
1. Verify all files uploaded successfully
2. Check file paths are correct
3. Ensure `index.html` is in `public_html/` root

### Admin Login Not Working

**Error:** `Invalid email or password`

**Solution:**
1. Verify admin account exists in database (check via phpMyAdmin)
2. Verify password is hashed with PASSWORD_BCRYPT
3. Check database user has privileges
4. Clear browser cookies and try again

### Images Not Loading

**Error:** Images return 404 or broken

**Solution:**
1. Verify `your-images/` folder exists and is writable (`755`)
2. Check image file names match exactly (case-sensitive on Linux)
3. Use full URLs: `https://yourdomain.com/your-images/image.jpg`

### HTTPS/SSL Issues

**Error:** `Mixed content` or `SSL certificate error`

**Solution:**
1. Install SSL certificate via **Auto SSL** in cPanel
2. Force HTTPS in `.htaccess` (see Step 8.5)
3. Update all URLs to use `https://` in code

### Slow Database Queries

**Solution:**
1. Optimize tables in phpMyAdmin
2. Check for missing database indexes
3. Consider upgrading hosting plan if traffic is high

---

## Quick Reference

### Important Paths & URLs

```
Website:              https://yourdomain.com
Admin Dashboard:      https://yourdomain.com/admin-dashboard.html
Admin Login:          https://yourdomain.com/admin-login.html
API Base:             https://yourdomain.com/api/
cPanel:               https://yourdomain.com:2083
phpMyAdmin:           https://yourdomain.com/cpanel/phpmyadmin
```

### Database Info Template

Save this for reference:

```
Database Name:        yourusername_gainer
Database User:        yourusername_gguser
Database Password:    [Your strong password]
Database Host:        localhost
```

### Admin Account Template

```
Admin Email:          [Your admin email]
Admin Password:       [Secure password]
```

---

## Support & Resources

- **cPanel Docs:** https://docs.cpanel.net
- **PHP Docs:** https://www.php.net/docs.php
- **MySQL Docs:** https://dev.mysql.com/doc
- **FileZilla Docs:** https://wiki.filezilla-project.org

---

## Deployment Checklist

Use this checklist to ensure complete deployment:

- [ ] Domain and cPanel access verified
- [ ] PHP version 7.4+ confirmed
- [ ] MySQL database created
- [ ] Database user created with all privileges
- [ ] All project files uploaded via FTP
- [ ] `config.php` updated with correct database credentials
- [ ] File permissions set correctly (644 for files, 755 for dirs)
- [ ] Database SQL imported successfully
- [ ] Admin account created successfully
- [ ] Homepage loads correctly
- [ ] Admin login works
- [ ] API endpoints respond with data
- [ ] `setup.php` deleted
- [ ] `hash.php` deleted (if created)
- [ ] `.setup-complete` deleted
- [ ] HTTPS/SSL enabled
- [ ] Error logs checked for issues
- [ ] Database tables optimized
- [ ] Website tested in multiple browsers

---

**Deployment Date:** ___________  
**Deployed By:** ___________  
**Status:** [ ] Active [ ] Testing [ ] Maintenance

---

**Last Updated:** April 20, 2026
