<?php
session_start();
require_once '../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if user is logged in and is admin
function checkAdminAuth() {
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Not logged in']);
        exit();
    }
    
    if ($_SESSION['user_role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Admin access required']);
        exit();
    }
}

// GET - List all users or get specific user
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    checkAdminAuth();
    
    try {
        if (isset($_GET['id'])) {
            // Get specific user
            $stmt = $pdo->prepare("SELECT id, email, full_name, role, status, created_at, last_login FROM users WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            $user = $stmt->fetch();
            
            if (!$user) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'User not found']);
                exit();
            }
            
            http_response_code(200);
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            // List all users
            $stmt = $pdo->prepare("SELECT id, email, full_name, role, status, created_at, last_login FROM users ORDER BY created_at DESC");
            $stmt->execute();
            $users = $stmt->fetchAll();
            
            http_response_code(200);
            echo json_encode(['success' => true, 'users' => $users, 'count' => count($users)]);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit();
}

// POST - Create new user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    checkAdminAuth();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['email']) || !isset($input['password']) || !isset($input['full_name'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Email, password, and full name required']);
        exit();
    }
    
    $email = filter_var($input['email'], FILTER_SANITIZE_EMAIL);
    $password = $input['password'];
    $full_name = trim($input['full_name']);
    $role = isset($input['role']) ? $input['role'] : 'admin';
    $status = 'active';
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit();
    }
    
    // Validate password length
    if (strlen($password) < 6) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
        exit();
    }
    
    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    
    try {
        // Check if email already exists
        $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $checkStmt->execute([$email]);
        if ($checkStmt->fetch()) {
            http_response_code(409);
            echo json_encode(['success' => false, 'message' => 'Email already exists']);
            exit();
        }
        
        // Insert new user
        $stmt = $pdo->prepare("INSERT INTO users (email, password, full_name, role, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$email, $hashedPassword, $full_name, $role, $status]);
        
        $userId = $pdo->lastInsertId();
        
        http_response_code(201);
        echo json_encode([
            'success' => true,
            'message' => 'User created successfully',
            'user' => [
                'id' => $userId,
                'email' => $email,
                'full_name' => $full_name,
                'role' => $role,
                'status' => $status
            ]
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit();
}

// PUT - Update user
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    checkAdminAuth();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'User ID required']);
        exit();
    }
    
    $userId = $input['id'];
    
    try {
        // Check if user exists
        $checkStmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
        $checkStmt->execute([$userId]);
        if (!$checkStmt->fetch()) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'User not found']);
            exit();
        }
        
        // Update user
        $updates = [];
        $params = [];
        
        if (isset($input['email'])) {
            $email = filter_var($input['email'], FILTER_SANITIZE_EMAIL);
            // Check if new email already exists
            $checkEmailStmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $checkEmailStmt->execute([$email, $userId]);
            if ($checkEmailStmt->fetch()) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'Email already exists']);
                exit();
            }
            $updates[] = "email = ?";
            $params[] = $email;
        }
        
        if (isset($input['full_name'])) {
            $updates[] = "full_name = ?";
            $params[] = trim($input['full_name']);
        }
        
        if (isset($input['status'])) {
            $updates[] = "status = ?";
            $params[] = $input['status'];
        }
        
        if (isset($input['password']) && !empty($input['password'])) {
            $hashedPassword = password_hash($input['password'], PASSWORD_BCRYPT);
            $updates[] = "password = ?";
            $params[] = $hashedPassword;
        }
        
        if (empty($updates)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'No fields to update']);
            exit();
        }
        
        $params[] = $userId;
        $stmt = $pdo->prepare("UPDATE users SET " . implode(", ", $updates) . " WHERE id = ?");
        $stmt->execute($params);
        
        http_response_code(200);
        echo json_encode(['success' => true, 'message' => 'User updated successfully']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit();
}

// DELETE - Delete user
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    checkAdminAuth();
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['id'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'User ID required']);
        exit();
    }
    
    $userId = $input['id'];
    
    // Prevent deleting own account
    if ($userId == $_SESSION['user_id']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Cannot delete your own account']);
        exit();
    }
    
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        
        if ($stmt->rowCount() > 0) {
            http_response_code(200);
            echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
        } else {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'User not found']);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
    exit();
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
